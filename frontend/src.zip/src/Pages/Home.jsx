
import{ useEffect,useContext } from 'react'
import axiosInstant from '../Axios/AxiosInstant'
import{useNavigate} from 'react-router-dom'
import { AuthContex } from '../Context/AuthProvider'

import '../Styles/Home.css'
import axios from 'axios'
import Hero from './Hero'
import TopCompanies from './TopCompanies'

function Home() {

  const navigate=useNavigate()
  const{setIsLoggedIn}=useContext(AuthContex)
//logout function
const logout=()=>{
  localStorage.removeItem('accesstoken')
  localStorage.removeItem('refreshtoken')
  setIsLoggedIn(false)
  navigate('/')
  console.log('user logedout')
}

  const jobs= async()=>{
  try{
    const res= await axiosInstant.get('company/jobs/',{})
    console.log(res.data)
    // const indianjob=res.data.jobs.filter((jobs)=>(jobs.companyName.lowercase==='tcs'))
    // console.log(indianjob)
  }
  catch(err){
    console.log(err)
  }
 }

 useEffect(()=>{jobs()},[])
  return ( 
    <>
<Hero/>
    </>
    
  )
}

export default Home