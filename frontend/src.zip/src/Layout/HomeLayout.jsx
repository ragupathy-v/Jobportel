
import { Outlet } from 'react-router-dom'
import Navbars from '../Components/Navbars'

function HomeLayout() {

  return (
    <>
    <Navbars />
    <div  style={{ paddingTop: "71px", 
                  background:'linear-gradient(150deg, #0a1628 0%, #112240 55%, #0f3460 100%)',
                  width:'100%',
                  minHeight:'100vh'
                  }}>
                    
         <Outlet/>
    </div>
   
    </>
  )
}

export default HomeLayout